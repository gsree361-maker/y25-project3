package com.klu.sbs.factory;

import com.klu.sbs.model.*;

public class AccountFactory {

    public static Account createAccount(
            String type, String accNo, String name, double balance) {

        switch (type.toUpperCase()) {
            case "SAVINGS":
                return new SavingsAccount(accNo, name, balance);

            case "CURRENT":
                return new CurrentAccount(accNo, name, balance, true);

            case "LOAN":
                return new LoanAccount(accNo, name, balance);

            default:
                throw new IllegalArgumentException("Invalid account type: " + type);
        }
    }
}

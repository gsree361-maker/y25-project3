package com.klu.sbs.exception;

public class NegativeAmountException extends Exception {
    public NegativeAmountException(String msg) {
        super(msg);
    }
}

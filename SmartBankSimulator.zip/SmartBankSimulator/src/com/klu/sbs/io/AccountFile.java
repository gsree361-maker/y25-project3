package com.klu.sbs.io;

import java.io.*;
import com.klu.sbs.factory.AccountFactory;
import com.klu.sbs.model.Account;

public class AccountFile {

    public static Account parse(String line) {
        String[] p = line.split(",");
        return AccountFactory.createAccount(p[1], p[0], p[2], Double.parseDouble(p[3]));
    }
}

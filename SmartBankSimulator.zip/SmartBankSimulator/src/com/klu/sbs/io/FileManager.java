package com.klu.sbs.io;

import com.klu.sbs.model.*;
import com.klu.sbs.factory.AccountFactory;

import java.io.*;
import java.util.*;

public class FileManager {

    private static final String FILE = "accounts.dat";

    // Load accounts from file
    public List<Account> loadAccounts() {
        List<Account> accounts = new ArrayList<>();

        File f = new File(FILE);
        if (!f.exists()) return accounts; // No file yet

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 4) continue;

                String accNo = parts[0];
                String type  = parts[1];
                String name  = parts[2];
                double bal   = Double.parseDouble(parts[3]);

                Account acc = AccountFactory.createAccount(type, accNo, name, bal);
                if (acc != null) accounts.add(acc);
            }
        } catch (Exception e) {
            System.out.println("Error loading accounts: " + e.getMessage());
        }

        return accounts;
    }

    // Save all accounts to file
    public void saveAccounts(List<Account> accounts) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE))) {
            for (Account acc : accounts) {
                String type = acc.getClass().getSimpleName().replace("Account","");
                bw.write(acc.getAccountNo() + "," + type.toUpperCase() + "," +
                         acc.getHolderName() + "," + acc.getBalance());
                bw.newLine();
            }
        } catch (Exception e) {
            System.out.println("Error saving accounts: " + e.getMessage());
        }
    }
}
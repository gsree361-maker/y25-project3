package com.klu.sbs.template;

import com.klu.sbs.model.Account;
import com.klu.sbs.service.BankService;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class BankMonthEndProcessor extends MonthEndProcessor {

    private BankService bank;

    public BankMonthEndProcessor(BankService bank) {
        this.bank = bank;
    }

    @Override
    protected List<Account> fetchAccounts() {
        // Get all accounts from BankService
        return bank.getAllAccounts();
    }

    @Override
    protected void applyInterest(List<Account> accounts) {
        for (Account acc : accounts) {
            acc.applyMonthlyInterest();
        }
        System.out.println("Monthly interest applied to all accounts.");
    }

    @Override
    protected void generateStatements(List<Account> accounts) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("statements.txt", true))) {
            bw.write("===== MONTH-END STATEMENTS =====\n");
            for (Account acc : accounts) {
                bw.write("Account No: " + acc.getAccountNo() +
                        ", Holder: " + acc.getHolderName() +
                        ", Balance: " + acc.getBalance() + "\n");
            }
            bw.write("===============================\n\n");
            System.out.println("Bank statements generated in statements.txt");
        } catch (IOException e) {
            System.out.println("Error writing statements: " + e.getMessage());
        }
    }
}

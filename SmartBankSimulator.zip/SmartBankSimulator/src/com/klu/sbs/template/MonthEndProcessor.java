package com.klu.sbs.template;

import com.klu.sbs.model.Account;

import java.util.List;

public abstract class MonthEndProcessor {

    // Template method
    public final void process() {
        List<Account> accounts = fetchAccounts();
        applyInterest(accounts);
        generateStatements(accounts);
    }

    // Steps to be implemented by subclasses
    protected abstract List<Account> fetchAccounts();

    protected abstract void applyInterest(List<Account> accounts);

    protected abstract void generateStatements(List<Account> accounts);
}

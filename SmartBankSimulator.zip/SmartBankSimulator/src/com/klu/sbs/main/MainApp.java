package com.klu.sbs.main;

import java.util.Scanner;
import com.klu.sbs.io.*;
import com.klu.sbs.service.*;
import com.klu.sbs.factory.AccountFactory;
import com.klu.sbs.model.*;
import com.klu.sbs.template.*;

public class MainApp {

    public static void main(String[] args) {

    	FileManager fm = new FileManager();
    	BankService bank = new BankService(fm);
        Scanner sc = new Scanner(System.in);

        System.out.println("===== SMART BANKING SIMULATOR =====");

        while (true) {

            System.out.print("\nEnter Account Number (or EXIT): ");
            String accNo = sc.next();

            if (accNo.equalsIgnoreCase("EXIT")) {
                System.out.println("Exiting application...");
                break;
            }

            Account acc = bank.getAccount(accNo);

            /* ================= CREATE ACCOUNT ================= */
            if (acc == null) {
                sc.nextLine(); 

                System.out.println("Account not found. Create new account.");

                System.out.print("Holder Name: ");
                String name = sc.nextLine();

                System.out.print("Account Type (SAVINGS / CURRENT / LOAN): ");
                String type = sc.next().toUpperCase();

                System.out.print("Opening Balance: ");
                double bal = sc.nextDouble();

                acc = AccountFactory.createAccount(type, accNo, name, bal);

                if (acc == null) {
                    System.out.println("Invalid account type!");
                    continue;
                }

                bank.addAccount(acc);
                System.out.println("Account created successfully!");
            }

            /* ================= ACCOUNT MENU ================= */
            int choice = 0;
            while (choice != 6) {

                System.out.println("\n--- ACCOUNT MENU (" + accNo + ") ---");
                System.out.println("1. Deposit");
                System.out.println("2. Withdraw");
                System.out.println("3. Transfer");
                System.out.println("4. View Balance");
                System.out.println("5. Month-End Process");
                System.out.println("6. Back");
                System.out.print("Enter choice: ");

                choice = sc.nextInt();

                switch (choice) {

                    case 1:
                        System.out.print("Enter deposit amount: ");
                        bank.deposit(accNo, sc.nextDouble());
                        break;

                    case 2:
                        System.out.print("Enter withdrawal amount: ");
                        bank.withdraw(accNo, sc.nextDouble());
                        // LoanAccount exception is thrown as it does not withdraw amount
                        break;

                    case 3:
                    	System.out.print("Transfer to Account Number: ");
                        String toAcc = sc.next();

                        if (bank.getAccount(toAcc) == null) {
                            System.out.println("Destination account not found.");
                            break;
                        }

                        System.out.print("Amount to transfer: ");
                        double tAmt = sc.nextDouble();

                        //  LoanAccount exception is thrown as it does not transfer amount
                        bank.transfer(accNo, toAcc, tAmt);
                        break;

                    case 4:
                        System.out.println("Current Balance: " +
                                bank.getAccount(accNo).getBalance());
                        break;

                    case 5:
                    	System.out.println("Running month-end process...");
                        BankMonthEndProcessor processor = new BankMonthEndProcessor(bank);
                        processor.process();
                        break;

                    case 6:
                        System.out.println("Returning to main menu...");
                        break;

                    default:
                        System.out.println("Invalid choice!");
                }
            }
        }

        sc.close();
        System.out.println("Thank you for using our Bank System.Have a Nice Day");
    }
}

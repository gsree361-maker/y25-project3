package com.klu.sbs.service;

public interface BankOperations {
    void deposit(String accNo, double amt);
    void withdraw(String accNo, double amt);
    void transfer(String from, String to, double amt);
    void monthEndProcess();
}

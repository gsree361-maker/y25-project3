package com.klu.sbs.service;

import java.util.*;
import com.klu.sbs.model.*;
import com.klu.sbs.exception.*;
import com.klu.sbs.io.FileManager;

public class BankService {

    private List<Account> accounts;
    private FileManager fm;

    public BankService(FileManager fm) {
        this.fm = fm;
        accounts = fm.loadAccounts(); // Load accounts at startup
    }

    public void addAccount(Account acc) {
        accounts.add(acc);
        fm.saveAccounts(accounts); // Save after add
    }

    public Account getAccount(String accNo) {
        for (Account a : accounts)
            if (a.getAccountNo().equals(accNo)) return a;
        return null;
    }

    public void deposit(String accNo, double amt) {
        try {
            getAccount(accNo).deposit(amt);
            fm.saveAccounts(accounts); // Save after deposit
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void withdraw(String accNo, double amt) {
        try {
            getAccount(accNo).withdraw(amt);
            fm.saveAccounts(accounts); // Save after withdrawal
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void transfer(String fromAccNo, String toAccNo, double amt) {
        Account fromAcc = getAccount(fromAccNo);
        Account toAcc   = getAccount(toAccNo);

        if (fromAcc == null || toAcc == null) {
            System.out.println("One or both accounts not found.");
            return;
        }

        try {
            fromAcc.withdraw(amt); // LoanAccount throws exception automatically
            toAcc.deposit(amt);
            fm.saveAccounts(accounts); // Save after transfer
            System.out.println("Transfer successful: " + amt + " from " +
                    fromAccNo + " to " + toAccNo);
        } catch (Exception e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }
    }

    public void monthEndProcess() {
        for (Account a : accounts) a.applyMonthlyInterest();
        fm.saveAccounts(accounts); // Save after month-end
    }

    public List<Account> getAllAccounts() {
        return accounts;
    }
}

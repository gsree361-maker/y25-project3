package com.klu.sbs.model;

import com.klu.sbs.exception.*;

public class SavingsAccount extends Account {

    private static final double INTEREST_RATE = 0.04; // 4% yearly

    public SavingsAccount(String acc, String name, double bal) {
        super(acc, name, bal);
    }

    @Override
    public void deposit(double amt) throws NegativeAmountException {
        if (amt < 0) throw new NegativeAmountException("Deposit cannot be negative");
        balance += amt;
    }

    @Override
    public void withdraw(double amt) throws InsufficientFundsException {
        if (amt > balance) throw new InsufficientFundsException("Not enough balance");
        balance -= amt;
    }

    @Override
    public void applyMonthlyInterest() {
        double monthlyInterest = balance * (INTEREST_RATE / 12);
        balance += monthlyInterest;
    }
}

package com.klu.sbs.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private String type; // Deposit / Withdraw / Transfer
    private double amount;
    private LocalDateTime dateTime;
    private String details; // Optional: e.g., "to ACC102"

    public Transaction(String type, double amount, String details) {
        this.type = type;
        this.amount = amount;
        this.details = details;
        this.dateTime = LocalDateTime.now();
    }

    public String getFormattedDate() {
        return dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    @Override
    public String toString() {
        return "[" + getFormattedDate() + "] " + type + " : " + amount +
               (details != null ? " (" + details + ")" : "");
    }
}

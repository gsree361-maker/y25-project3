package com.klu.sbs.model;

import com.klu.sbs.exception.*;


public abstract class Account {
	
    protected String accountNo;
    protected String holderName;
    protected double balance;
    protected int features;   // bitwise flags

    public Account(String accountNo, String holderName, double balance) {
        this.accountNo = accountNo;
        this.holderName = holderName;
        this.balance = balance;
    }

    public abstract void deposit(double amt) throws NegativeAmountException;

    public abstract void withdraw(double amt) throws InsufficientFundsException;

    public abstract void applyMonthlyInterest();

    public String getAccountNo() { return accountNo; }
    public String getHolderName() { return holderName; }
    public double getBalance() { return balance; }

    public int getFeatures() { return features; }
    
    
}

package com.klu.sbs.model;

import com.klu.sbs.exception.*;

public class LoanAccount extends Account {

    private static final double intrest = 0.12;  // 12% annual

    public LoanAccount(String acc, String name, double bal) {
        super(acc, name, bal);
    }

    @Override
    public void deposit(double amt) throws NegativeAmountException {
        if (amt <= 0) throw new NegativeAmountException("Amount cannot be zero (or) negative");
        balance -= amt;  // Paying back the  loan
    }

    @Override
    public void withdraw(double amt) throws UnsupportedOperationException {
        // LoanAccount cannot withdraw or transfer money
        throw new UnsupportedOperationException(
            "Withdrawal / Transfer not allowed from Loan Account"
        );
    }

    @Override
    public void applyMonthlyInterest() {
        double monthly = intrest / 12;
        balance = balance * (1 + monthly);
    }
}

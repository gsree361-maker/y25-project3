package com.klu.sbs.model;

import com.klu.sbs.exception.*;

public class CurrentAccount extends Account {

    public static final int overdraft = 1 << 2; // bit flag

    public CurrentAccount(String acc, String name, double bal, boolean overdraftAllowed) {
        super(acc, name, bal);
        if (overdraftAllowed) {
            features |= overdraft;
        }
    }

    @Override
    public void deposit(double amt) throws NegativeAmountException {
        if (amt <= 0) throw new NegativeAmountException("Deposit cannot be  zero (or)  negative");
        balance += amt;
    }

    @Override
    public void withdraw(double amt) throws InsufficientFundsException {
        if (amt > balance) {
            if ((features & overdraft) == 0)
                throw new InsufficientFundsException("Overdraft not allowed");
        }
        balance -= amt;
    }

    @Override
    public void applyMonthlyInterest() {
        // There is no interest for current accounts
    }
}

/**
 * 
 */
/**
 * 
 */
module SmartBankSimulator {
}